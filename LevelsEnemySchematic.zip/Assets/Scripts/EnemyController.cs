﻿using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public Vector3[] schedule = {new Vector3(0, 0, 0), new Vector3(1,1,1) };
    public Vector3[] tacticMovement;
    public bool patrolMode = true;
    public bool followPlayerMode = false;
    public float speed = 0.02f;
    public float rotationSpeed = 80f;
    public float closeScheduleDistance = 0.3f;
    public float noticePlayerDistance = 8f;
    public float followPlayerDistance = 5f;
    Vector3 currentGoal;
    int currentGoalId;
    Transform anchor;
    Transform enemy;
    Transform level;
    Transform player;
    
    // Start is called before the first frame update
    void Start()
    {
        currentGoalId = 0;
        UnityEngine.Debug.Log("schedule.Length:" + schedule.Length);
        if (schedule.Length > 0) {
            currentGoal = schedule[currentGoalId % schedule.Length];
            UnityEngine.Debug.Log(schedule[0]);
        } else
        {
            currentGoal = new Vector3 (0, 0, 0);
        }
        player = GameObject.FindWithTag("Player").transform;

        level = transform.parent.GetComponent<Transform>();

        int numOfChilds = transform.childCount;
        UnityEngine.Debug.Log("numChild:" + numOfChilds);
        for (int i = 0; i < numOfChilds; ++i) {
            if (transform.GetChild(i).name == "Anchor")
            {
                anchor = transform.GetChild(i);
            }
            if (transform.GetChild(i).name == "EnemyBody")
            {
                enemy = transform.GetChild(i);
            }
        }
        anchor.localPosition = transform.InverseTransformPoint(level.TransformPoint(currentGoal));

     //   UnityEngine.Debug.Log("anchor.position:" + anchor.position);

      // UnityEngine.Debug.Log("curGoal:" + currentGoal);
    //    UnityEngine.Debug.Log("curAnchor:" + anchor.localPosition);
        enemy.LookAt(anchor);

     //   UnityEngine.Debug.Log("FcurGoal:" + currentGoal);
      //  UnityEngine.Debug.Log("FcurAnchor:" + anchor.localPosition);

    }
    
  /*  void rotateTowards(Transform obj)
    {
        enemy.rotation = Quaternion.RotateTowards(enemy.rotation, Quaternion., rotationSpeed*Time.deltaTime);
        UnityEngine.Debug.Log("r" + enemy.rotation);
    }*/

    // Update is called once per frame
    void Update()
    {

        if (patrolMode && schedule.Length >= 2)
        {
            Vector3 direction = anchor.position - enemy.position;
            direction.z = 0;

            Vector3 vecToPlayer = ( player.position)  - (enemy.position);
            float distanceToPlayer = Mathf.Sqrt(vecToPlayer.x * vecToPlayer.x + vecToPlayer.y * vecToPlayer.y);



              //UnityEngine.Debug.Log("pPos:" + player.position + "ePos" + enemy.position + "dist:" + distanceToPlayer);
           

            if (Mathf.Sqrt(direction.x * direction.x + direction.y * direction.y) < closeScheduleDistance)
            {
                ++currentGoalId;
                currentGoal = schedule[currentGoalId % schedule.Length];
                UnityEngine.Debug.Log("newGoal:" + currentGoal);
                anchor.localPosition = transform.InverseTransformPoint(level.TransformPoint(currentGoal));

                if (currentGoalId % schedule.Length == 0)
                {
                    currentGoalId = 0;
                }
            }
            direction = Vector3.Normalize(direction);

            enemy.Translate(direction * speed * Time.deltaTime, Space.World);

          //  if (distanceToPlayer < noticePlayerDistance)
         //   {
                // enemy.LookAt(player);
          //      rotateTowards(player);
       //     }
         //   else
        //    {
                enemy.LookAt(anchor);
              //  rotateTowards(anchor);
         //   }
         /*

              if (distanceToPlayer < followPlayerDistance)
              {
                  patrolMode = false;
                  followPlayerMode = true;
                  currentGoal = level.InverseTransformPoint(player.position);
                  anchor.localPosition = transform.InverseTransformPoint(level.TransformPoint(currentGoal));
              }*/
        }
      /*  else if (followPlayerMode)
        {
            Vector3 direction = anchor.position - enemy.position;
            direction.z = 0;
            enemy.LookAt(anchor);

            if (Mathf.Sqrt(direction.x * direction.x + direction.y * direction.y) > noticePlayerDistance)
            {
                followPlayerMode = false;
                patrolMode = true;
                currentGoal = schedule[currentGoalId % schedule.Length];
                anchor.localPosition = transform.InverseTransformPoint(level.TransformPoint(currentGoal));


            } else
            {
                direction = Vector3.Normalize(direction);
                enemy.Translate(direction * speed * Time.deltaTime, Space.World);
            }
           

        }*/
  

    }
}
