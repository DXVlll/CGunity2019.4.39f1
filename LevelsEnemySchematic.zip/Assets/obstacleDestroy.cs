﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class obstacleDestroy : MonoBehaviour
{
    void destroy(){
        Destroy(this.gameObject);
    }
}
