﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public static class GameManager
{
    public const string levelTag = "Level";
    public static string currentLevelString = "Level 1";

    public static GameObject currentLevel;
    public static bool loadLevelByString = true;
    
    public static int score;
    
    public static void IncreaseScore()
    {
     score++;
     Debug.Log("Score");
    }

    public static void loadLevel(GameObject nextLlevel, GameObject previousLevel)
    {
        previousLevel.SetActive(false);

        GameManager.currentLevel = null;
        GameManager.currentLevelString = nextLlevel.name;

    //    GameManager.loadLevelByString = false;
        
 //       string currentSceneName = SceneManager.GetActiveScene().name;
        SceneManager.LoadScene(nextLlevel.scene.name);
     //   GameObject sManager = GameObject.FindWithTag("SceneManager");
       // CustomSceneManager customSceneManager = sManager.GetComponent<CustomSceneManager>();
     //   customSceneManager.intitialize();
    }
}
