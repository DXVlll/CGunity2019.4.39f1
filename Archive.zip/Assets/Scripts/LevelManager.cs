﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelManager : MonoBehaviour
{
    public Transform spawn;

    public void load(GameObject player, PlayerManager playerManager) {
      //  player.SetActive(false);
        player.transform.position = spawn.position;
        Physics.SyncTransforms(); // added for teleport to work properly

        playerManager.lastSpawn = spawn;
      //  player.SetActive(true);

        UnityEngine.Debug.Log("I have set player position to spawn");
    }

    void Start()
    {
        UnityEngine.Debug.Log("Level loaded spawn:(" + spawn.position.x + ", " + spawn.position.y + ", " + spawn.position.z + ")");
      
    }
}
